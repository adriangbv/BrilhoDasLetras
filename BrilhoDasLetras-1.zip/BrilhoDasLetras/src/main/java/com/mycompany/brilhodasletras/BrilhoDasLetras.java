/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.brilhodasletras;

/**
 *
 * @author hercu
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class BrilhoDasLetras {
    public static void main(String[] args) {
        MainMenu mainMenu = new MainMenu();
        mainMenu.run();
    }
}













                
                
                
                
                

